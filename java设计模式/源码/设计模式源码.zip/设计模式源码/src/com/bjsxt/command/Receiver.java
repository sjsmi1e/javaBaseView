package com.bjsxt.command;

/**
 * 真正的命令的执行者
 * @author Administrator
 *
 */
public class Receiver {
	public void action(){
		System.out.println("Receiver.action()");
	}
}
