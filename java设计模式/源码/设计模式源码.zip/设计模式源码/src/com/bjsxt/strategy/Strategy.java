package com.bjsxt.strategy;

public interface Strategy {
	public double getPrice(double  standardPrice);
}
