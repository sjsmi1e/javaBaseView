package com.bjsxt.observer;

public interface Observer {
	void  update(Subject subject);
}
