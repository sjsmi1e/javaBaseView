package com.bjsxt.state;

public interface State {
	void handle();
}
