package com.bjsxt.adapter;

public interface Target {
	void handleReq();
}
