package com.bjsxt.factory.factorymethod;

public interface CarFactory {
	Car createCar();
}
