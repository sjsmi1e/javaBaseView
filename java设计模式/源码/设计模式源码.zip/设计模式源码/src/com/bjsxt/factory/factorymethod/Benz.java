package com.bjsxt.factory.factorymethod;

public class Benz implements Car {

	@Override
	public void run() {
		System.out.println("奔驰再跑！");
	}

}
