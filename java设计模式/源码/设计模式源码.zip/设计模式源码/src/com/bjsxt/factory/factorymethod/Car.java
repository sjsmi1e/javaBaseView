package com.bjsxt.factory.factorymethod;

public interface Car {
	void run();
}
