package com.bjsxt.factory.simplefactory;

public interface Car {
	void run();
}
