package com.bjsxt.factory.factorymethod;

public class Audi implements Car {

	@Override
	public void run() {
		System.out.println("奥迪再跑！");
	}

}
