package com.bjsxt.factory.factorymethod;

public class Byd implements Car {

	@Override
	public void run() {
		System.out.println("比亚迪再跑！");
	}

}
